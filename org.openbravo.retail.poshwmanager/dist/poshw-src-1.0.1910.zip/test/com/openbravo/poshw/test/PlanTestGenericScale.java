/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.openbravo.poshw.test;

import com.openbravo.pos.scale.ScaleException;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author adrian
 */
public class PlanTestGenericScale {
    
    public PlanTestGenericScale() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

     @Test
     public void testing() throws ScaleException, UnsupportedEncodingException {

            TestGenericScale scale = new TestGenericScale("R", "\\n", "([0-9]*)\\.([0-9]*)", "");
            System.out.println(scale.parseWeight("123.305".getBytes()));
            
            scale = new TestGenericScale("R", "\\n", "([0-9]*)", "0.001");
            System.out.println(scale.parseWeight("123305".getBytes()));
  
     }
}