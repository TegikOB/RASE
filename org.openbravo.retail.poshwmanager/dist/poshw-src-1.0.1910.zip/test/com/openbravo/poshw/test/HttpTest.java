/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw.test;

import com.openbravo.pos.util.HttpServices;
import java.io.IOException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author adrian
 */
public class HttpTest {

    public HttpTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

     @Test
     public void hello() throws IOException {
         
         String query =
                 
            "<TransactionSetup  xmlns=\"https://transaction.elementexpress.com\">\n" +
            "<Credentials>\n" +
            "    <AccountID>1009585</AccountID>\n" +
            "    <AccountToken>3356680BC6F90F192E5C904F580BE35BCD41A731841E1165255243BA2A94D4B9FA266A01</AccountToken>\n" +
            "    <AcceptorID>3928907</AcceptorID>\n" +
            "</Credentials>\n" +
            "<Application>\n" +
            "    <ApplicationID>1336</ApplicationID>\n" +
            "    <ApplicationName>OpenbravoPOS</ApplicationName>\n" +
            "    <ApplicationVersion>1.2.3</ApplicationVersion>\n" +
            "</Application>\n" +

            "<Terminal>\n" +
            "    <TerminalID>1234</TerminalID>\n" +
            "    <CardPresentCode></CardPresentCode>\n" +
            "    <CardholderPresentCode></CardholderPresentCode>\n" +
            "    <CardInputCode></CardInputCode>\n" +
            "    <CVVPresenceCode></CVVPresenceCode>\n" +
            "    <TerminalCapabilityCode></TerminalCapabilityCode>\n" +
            "    <TerminalEnvironmentCode></TerminalEnvironmentCode>\n" +
            "    <MotoECICode></MotoECICode>\n" +
            "</Terminal>\n" +

            "<TransactionSetup>\n" +
            "    <TransactionSetupMethod>1</TransactionSetupMethod>\n" +
            "    <Embedded>0</Embedded>\n" +
            "</TransactionSetup>\n" +

            "<Transaction>\n" +
            "    <TransactionAmount>23</TransactionAmount>\n" +
            "</Transaction>\n" +
            "</TransactionSetup>";

        System.out.println(HttpServices.doPost("https://certtransaction.elementexpress.com", "text/xml;charset=utf-8", query));

     }

}