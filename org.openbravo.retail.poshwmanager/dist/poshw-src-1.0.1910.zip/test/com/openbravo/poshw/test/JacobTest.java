/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw.test;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Administrator
 */
public class JacobTest {
    
    public JacobTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
 
     @Test
     public void hello() {
     
         ActiveXComponent activex = new ActiveXComponent("EltradeFPAx.EltradeFprn");
         Dispatch obj = activex.getObject();
         Dispatch.call(obj, "Init", 1, 115200, 0, 3, 0, "");
         Dispatch.call(obj, "RunPrinterTest");
         Dispatch.call(obj, "Close");
         
     
     }
}
