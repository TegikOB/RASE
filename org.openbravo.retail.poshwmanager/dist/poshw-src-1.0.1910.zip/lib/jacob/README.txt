JACOB (Java-COM bridge) is hosted on Sourceforge http://sourceforge.net/projects/jacob-project

Information about what's new in this release can be found in docs/ReleaseNotes.html

Instructions on building this project can be found in docs/BuildingJacobFromSource.html
Detailed instructions on creating a build configuration file are in build.xml

Put the appropriate DLL for your platform into your runtime library path.
jacob for 32 bit windows is located in /x86.

There is no good usage guide at this time.