/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw.server;

import Acme.Serve.Serve;
import com.openbravo.poshw.AppConfig;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServlet;

/**
 * An implemtation of the ServerManager using the small TJWS servlet container
 * It works but the support for exceptions is very weak. It cannot be detected
 * whether the server started successfully or failed.
 *
 * @author adrian
 */
public class ServerManagerTJWS implements ServerManager {

    private final static Logger logger = Logger.getLogger(ServerManagerTJWS.class.getName());

    private Serve srv = null;
    private ServerListener listener;

    private boolean srvrunning = false;
    private int srvport = 0;
    private Map<String, HttpServlet> servlets = new HashMap<String, HttpServlet>();

    public void init(AppConfig config) {

        srv = new Serve();
        srvrunning = false;
        srvport = Integer.parseInt(config.getProperty("server.port"));

        java.util.Properties properties = new java.util.Properties();
        properties.put("port", srvport);
        properties.setProperty(Serve.ARG_NOHUP, "nohup");
        srv.arguments = properties;

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                ServerManagerTJWS.this.stop();
            }
        });
    }

    public void setListener(ServerListener listener) {
        this.listener = listener;
    }

    public void addServlet(String path, HttpServlet servlet) {
        logger.log(Level.INFO, "Adding servlet to: {0}", path);
        servlets.put(path, servlet);
    }

    public void start() {
        if (!srvrunning) {

            for (Entry<String, HttpServlet> entry : servlets.entrySet()) {
                srv.addServlet(entry.getKey(), entry.getValue());
            }

            Thread t = new Thread(new Runnable() {
                public void run() {
                    srv.serve();
                }
            });

            logger.info("TJWS Starting.");
            if (listener != null) {
                listener.starting();
            }

            t.start();

            srvrunning = true;
            logger.info("TJWS Started.");
            if (listener != null) {
                listener.started();
            }
        }
    }

    public void stop() {
        if (srvrunning) {
            logger.info("TJWS Stopping.");
            if (listener != null) {
                listener.stopping();
            }        
            srv.notifyStop();
            srv.destroyAllServlets();
            srvrunning = false;
            logger.info("TJWS Stopped.");
            if (listener != null) {
                listener.stopped();
            }
        }
    }

    public int getState() {
        return srvrunning ? ServerManager.STARTED : ServerManager.STOPPED;
    }

    public String printName() {

        StringBuilder status = new StringBuilder();
        status.append("TJWS web server version ");
        status.append(srv.getMajorVersion());
        status.append(".");
        status.append(srv.getMinorVersion());
        return status.toString();
    }

    public String printStatus() {

        StringBuilder status = new StringBuilder();
        status.append(srvrunning ? "STARTED" : "STOPPED");
        if (srvrunning) {
            status.append(". Listening on: http://");
            try {
                status.append(java.net.InetAddress.getLocalHost().getCanonicalHostName());
            } catch (UnknownHostException ex) {
                status.append("<unknown address>");
            }
            status.append(":");
            status.append(Integer.toString(srvport));        
        } else {
            status.append(".");
        }

        return status.toString();
    }
}
