/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

import com.openbravo.pos.scale.DeviceScale;
import com.openbravo.pos.scale.ScaleException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

/**
 *
 * @author adrian
 */
public class ScaleServlet extends CORSHttpServlet  {

    private DeviceScale ds;

    public ScaleServlet(DeviceScale ds) {
        this.ds = ds;
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        setCORSHeaders(request, response);
        response.setContentType("application/json");

        try {
            JSONObject o = new JSONObject();
            try {
                o.put("result", ds.readWeight());
            } catch (JSONException ex) {
            }
            response.getWriter().println(JSONUtils.getJSONP(request.getParameter("callback"), o));
        } catch (ScaleException ex) {
            Logger.getLogger(ScaleServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.getWriter().println(JSONUtils.getExceptionJSONP(request.getParameter("callback"), ex));
        }
    }
}
