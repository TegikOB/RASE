/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

/**
 *
 * @author adrian
 */
public class License {

    public static final String LICENSE_TEXT =
             "************************************************************************************\n" +
             "* POS Hardware Manager.\n" +
             "* Copyright (C) 2012 Openbravo S.L.U.\n" +
             "* Licensed under the Openbravo Commercial License version 1.0\n" +
             "* You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html\n" +
             "* or in the legal folder of this module distribution.\n" +
             "************************************************************************************\n";
    public static final String LICENSE_HTML =
             "<html>" +
             "Copyright (C) 2012 Openbravo S.L.U.<br>" +
             "Licensed under the Openbravo Commercial License version 1.0<br>" +
             "You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html<br>" +
             "or in the legal folder of this module distribution.<br>";


}
