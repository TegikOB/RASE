/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.poshw;

/**
 *
 * @author adrianromero
 */
public class AppLocal {

//    private static ResourceBundle r;

    /** Creates a new instance of AppLocal */
    private AppLocal() {
    }

    public static String getIntString(String sKey) {
        if (sKey == null) {
            return null;
        } else  {
            // return r.getString(sKey);
            return "** " + sKey + " **";
        }
    }

    public static String getIntString(String sKey, Object ... sValues) {

        if (sKey == null) {
            return null;
        } else  {
            // return MessageFormat.format(r.getString(sKey), sValues);
            StringBuilder sreturn = new StringBuilder();
            sreturn.append("** ");
            sreturn.append(sKey);
            for (Object value : sValues) {
                sreturn.append(" < ");
                sreturn.append(value.toString());
            }
            sreturn.append("** ");

            return sreturn.toString();
        }
    }
}
