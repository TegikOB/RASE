package com.openbravo.pos.fiscal;
/*
 ************************************************************************************
 * Copyright (C) 2013 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

import com.openbravo.pos.printer.DeviceFiscalPrinter;
import com.openbravo.pos.printer.HardwareException;
import com.openbravo.pos.printer.escpos.PrinterWritter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.swing.JComponent;


/**
 *
 * @author adrian
 */
public class DeviceFiscalSerialEltrade implements DeviceFiscalPrinter {

    private static final byte ADDRESS = (byte)0x00;

    private static final byte INS_TEST = (byte)0x24;
    private static final byte INS_TESTMEMORYREAD = (byte)0x25;
    private static final byte INS_DAILYREPORT = (byte)0x33;

    private PrinterWritter out;
    private byte frame = 0x00;
    
    public DeviceFiscalSerialEltrade(PrinterWritter out) {
        this.out = out;
    }

    public String getFiscalName() {
        return "Eltrade fiscal printer";
    }
    public String getFiscalDescription() {
        return out.getDescription();
    }
    public JComponent getFiscalComponent() {
        return null;
    }

    public void reset() throws HardwareException {
        // sendInstruction(INS_DAILYREPORT, new byte[] {0x00, 0x00});
        // sendInstruction(INS_TESTMEMORYREAD);
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void test() throws HardwareException {
//        sendInstruction((byte)0x3b); // Void all
//        sendInstruction((byte)0x70); // Printer Status
        sendInstruction(INS_TEST);
    }

    public void beginReceipt(String type, String cashier) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    public void beginReceipt(String type, String cashier, String invNumber, String taxNumber, String vatNumber, String name, String address) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public void endReceipt() throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void printLine(String sproduct, double dprice, double dunits, int taxinfo) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    public void printLine(String sproduct, double dprice, double dunits, int taxinfo, double discount) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void printMessage(String style, String smessage) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void printDiscount(double discount) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void printServiceCharge(double amount) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public void printTotal(int paymentId, String paymentName, double amount) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void printCashManagement(int paymentId, String paymentName, double amount) throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void printZReport() throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void printXReport() throws HardwareException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private void sendInstruction(byte command) {
        sendInstruction(command, new byte[]{});
    }

    private void beginDocument() {
        sendInstruction((byte)0x2D);
    }

    private void endDocument() {
        sendInstruction((byte)0x2F);
    }

    private void printComment(String txt) {

        ByteArrayOutputStream data = new ByteArrayOutputStream();
        try {
            data.write(new byte[]{0x01});
            data.write(txt.getBytes());
        } catch (IOException ex) {
        }

        sendInstruction((byte)0x2E, data.toByteArray());
    }

    private void sendInstruction(byte command, byte[] data) {

        frame++;

        out.write(new byte[] {(byte)0xAA, (byte)0x55, ADDRESS, frame, command});
        byte cf = (byte)(ADDRESS + frame + command);

        out.write((byte)data.length);
        cf += (byte)data.length;
        out.write(data);
        for (int i = 0; i < data.length; i++) {
            cf += data[i];
        }

        out.write((byte)-cf);
        out.flush();
    }
}
