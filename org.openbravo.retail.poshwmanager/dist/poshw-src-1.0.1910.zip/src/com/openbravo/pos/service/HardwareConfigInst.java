/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.service;

import com.openbravo.pos.printer.TicketPrinterException;
import com.openbravo.pos.printer.escpos.PrinterWritter;
import com.openbravo.pos.printer.escpos.PrinterWritterFile;
import com.openbravo.pos.printer.escpos.PrinterWritterRXTX;
import com.openbravo.pos.util.StringParser;
import com.openbravo.poshw.AppConfig;
import gnu.io.SerialPort;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author adrian
 */
public class HardwareConfigInst implements HardwareConfig {

    private String param1;
    private String param2;

    private AppConfig config;

    private Map<String, PrinterWritter> m_apool = new HashMap<String, PrinterWritter>();

    public HardwareConfigInst(AppConfig config) {
        this.config = config;
    }

    public void setParameters(String param1, String param2) {
        this.param1 = param1;
        this.param2 = param2;
    }

    public String getParameter1() {
        return param1;
    }

    public String getParameter2() {
        return param2;
    }

    public String getConfigProperty(String prop) {
        return config.getProperty(prop);
    }

    public PrinterWritter createPrinterWritter() throws TicketPrinterException {
        String skey = param1 + "-->" + param2;
        PrinterWritter pw = (PrinterWritter) m_apool.get(skey);
        if (pw == null) {
            if ("serial".equals(param1) || "rxtx".equals(param1)) {
                StringParser p = new StringParser(param2);
                pw = new PrinterWritterRXTX(
                        p.nextToken(','),
                        parseInt(p.nextToken(','), 9600),
                        parseInt(p.nextToken(','), SerialPort.DATABITS_8),
                        parseInt(p.nextToken(','), SerialPort.STOPBITS_1),
                        parseInt(p.nextToken(','), SerialPort.PARITY_NONE),
                        parseInt(p.nextToken(','), SerialPort.FLOWCONTROL_NONE));
                m_apool.put(skey, pw);
            } else if ("file".equals(param1)) {
                pw = new PrinterWritterFile(param2);
                m_apool.put(skey, pw);
            } else {
                throw new TicketPrinterException();
            }
        }
        return pw;
    }

    private static int parseInt(String sValue, int iDefault) {
        try {
            return Integer.parseInt(sValue);
        } catch (NumberFormatException eNF) {
            return iDefault;
        }
    }
}
