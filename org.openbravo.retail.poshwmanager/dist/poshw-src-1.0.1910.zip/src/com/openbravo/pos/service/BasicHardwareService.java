/*
 ************************************************************************************
 * Copyright (C) 2012 - 2014 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.service;

import com.openbravo.pos.fiscal.DeviceFiscalActiveXEltrade;
import com.openbravo.pos.printer.DeviceDisplay;
import com.openbravo.pos.printer.DeviceDisplayNull;
import com.openbravo.pos.printer.DeviceFiscalPrinter;
import com.openbravo.pos.printer.DevicePrinter;
import com.openbravo.pos.printer.DevicePrinterNull;
import com.openbravo.pos.printer.escpos.CodesEpson;
import com.openbravo.pos.printer.escpos.CodesIthaca;
import com.openbravo.pos.printer.escpos.CodesStar;
import com.openbravo.pos.printer.escpos.CodesSurePOS;
import com.openbravo.pos.printer.escpos.CodesTMU220;
import com.openbravo.pos.printer.escpos.DeviceDisplayESCPOS;
import com.openbravo.pos.printer.escpos.DeviceDisplayLD9000;
import com.openbravo.pos.printer.escpos.DeviceDisplaySurePOS;
import com.openbravo.pos.printer.escpos.DevicePrinterESCPOS;
import com.openbravo.pos.printer.escpos.DevicePrinterPlain;
import com.openbravo.pos.printer.escpos.UnicodeTranslatorEur;
import com.openbravo.pos.printer.escpos.UnicodeTranslatorInt;
import com.openbravo.pos.printer.escpos.UnicodeTranslatorStar;
import com.openbravo.pos.printer.escpos.UnicodeTranslatorSurePOS;
import com.openbravo.pos.printer.printer.DevicePrinterPrinter;
import com.openbravo.pos.printer.screen.DeviceDisplayPanel;
import com.openbravo.pos.printer.screen.DeviceDisplayWindow;
import com.openbravo.pos.printer.screen.DevicePrinterPanel;
import com.openbravo.pos.scale.DeviceScale;
import com.openbravo.pos.scale.GenericContinuousScale;
import com.openbravo.pos.scale.GenericScale;
import com.openbravo.pos.scale.ScaleDialog1;
import com.openbravo.pos.scale.ScaleFake;
import com.openbravo.pos.scale.ScaleNull;
import com.openbravo.pos.scale.ScaleSamsungEsp;
import com.openbravo.pos.scale.ScaleScreen;
import java.awt.Font;
import java.awt.geom.AffineTransform;

/**
 *
 * @author adrian
 */
public class BasicHardwareService implements HardwareService {

    public DeviceDisplay getDisplay(String type, HardwareConfig hwconfig) throws Exception {

        if ("screen".equals(type)) {
            return new DeviceDisplayPanel();
        } else if ("window".equals(type)) {
            return new DeviceDisplayWindow();
        } else if ("epson".equals(type)) {
            return new DeviceDisplayESCPOS(hwconfig.createPrinterWritter(), new UnicodeTranslatorInt());
        } else if ("surepos".equals(type)) {
            return new DeviceDisplaySurePOS(hwconfig.createPrinterWritter());
        } else if ("ld200".equals(type)) {
            return new DeviceDisplayESCPOS(hwconfig.createPrinterWritter(), new UnicodeTranslatorEur());        
        } else if ("ld9000".equals(type)) {
            return new DeviceDisplayLD9000(hwconfig.createPrinterWritter());            
        } else if ("eltrade".equals(type)) {
            return new DeviceFiscalActiveXEltrade(hwconfig.getParameter1(), hwconfig.getParameter2());            
        } else if ("null".equals(type)) {
            return new DeviceDisplayNull();
        } else {
            return null;
        }
    }

    public DevicePrinter getPrinter(String type, HardwareConfig hwconfig) throws Exception {

        if ("screen".equals(type)) {
            return new DevicePrinterPanel();
        } else if ("printer".equals(type)) {
            String p2 = hwconfig.getParameter2();

            // backward compatibility
            if (p2 == null || p2.equals("") || p2.equals("true")) {
                p2 = "receipt";
            } else if (p2.equals("false")) {
                p2 = "standard";
            }
            
            Font f = new Font(hwconfig.getConfigProperty("paper." + p2 + ".fontName"), 
                Font.PLAIN, 
                Integer.parseInt(hwconfig.getConfigProperty("paper." + p2 + ".fontSize")));
            double fontwidth = Double.parseDouble(hwconfig.getConfigProperty("paper." + p2 + ".fontWidth")); // 1.00 by default
            double fontheight = Double.parseDouble(hwconfig.getConfigProperty("paper." + p2 + ".fontHeight")); // 1.40 by default
            
            if (fontwidth != 1.0 || fontheight != 1.0) {
                f = f.deriveFont(AffineTransform.getScaleInstance(fontwidth, fontheight));
            }

            return new DevicePrinterPrinter(hwconfig.getParameter1(),
                    Integer.parseInt(hwconfig.getConfigProperty("paper." + p2 + ".x")),
                    Integer.parseInt(hwconfig.getConfigProperty("paper." + p2 + ".y")),
                    Integer.parseInt(hwconfig.getConfigProperty("paper." + p2 + ".width")),
                    Integer.parseInt(hwconfig.getConfigProperty("paper." + p2 + ".height")),
                    hwconfig.getConfigProperty("paper." + p2 + ".mediasizename"),
                    f,
                    Float.parseFloat(hwconfig.getConfigProperty("paper." + p2 + ".fontLength")), // 0.0 by default
                    Integer.parseInt(hwconfig.getConfigProperty("paper." + p2 + ".lineHeight")),
                    Double.parseDouble(hwconfig.getConfigProperty("paper." + p2 + ".imageScale")));
        } else if ("epson".equals(type)) {
            return new DevicePrinterESCPOS(hwconfig.createPrinterWritter(), new CodesEpson(), new UnicodeTranslatorInt());
        } else if ("tmu220".equals(type)) {
            return new DevicePrinterESCPOS(hwconfig.createPrinterWritter(), new CodesTMU220(), new UnicodeTranslatorInt());
        } else if ("star".equals(type)) {
            return new DevicePrinterESCPOS(hwconfig.createPrinterWritter(), new CodesStar(), new UnicodeTranslatorStar());
        } else if ("ithaca".equals(type)) {
            return new DevicePrinterESCPOS(hwconfig.createPrinterWritter(), new CodesIthaca(), new UnicodeTranslatorInt());
        } else if ("surepos".equals(type)) {
            return new DevicePrinterESCPOS(hwconfig.createPrinterWritter(), new CodesSurePOS(), new UnicodeTranslatorSurePOS());
        } else if ("plain".equals(type)) {
            return new DevicePrinterPlain(hwconfig.createPrinterWritter());
//                } else if ("javapos".equals(sPrinterType)) {
//                    addPrinter(sPrinterIndex, new DevicePrinterJavaPOS(sPrinterParam1, sPrinterParam2));
        } else if ("null".equals(type)) {
            return new DevicePrinterNull();
        } else {
            return null;
        }
    }

    public DeviceScale getScale(String type, HardwareConfig hwconfig) throws Exception {
        
       if ("generic".equals(type)) {
           return new GenericScale(hwconfig.getParameter1(), hwconfig.getParameter2(),                  
                   hwconfig.getConfigProperty("machine.scale.generic.command"),
                   hwconfig.getConfigProperty("machine.scale.generic.final"),
                   hwconfig.getConfigProperty("machine.scale.generic.pattern"),
                   hwconfig.getConfigProperty("machine.scale.generic.factor"));
        } else if ("genericcontinuous".equals(type)){
           return new GenericContinuousScale(hwconfig.getParameter1(), hwconfig.getParameter2(),   
                   hwconfig.getConfigProperty("machine.scale.genericcontinuous.final"),
                   hwconfig.getConfigProperty("machine.scale.genericcontinuous.pattern"),
                   hwconfig.getConfigProperty("machine.scale.genericcontinuous.factor"));
        } else if ("dialog1".equals(type)) {
            return new ScaleDialog1(hwconfig.getParameter1(), hwconfig.getParameter2());
        } else if ("samsungesp".equals(type)) {
            return new ScaleSamsungEsp(hwconfig.getParameter1(), hwconfig.getParameter2());
        } else if ("screen".equals(type)) { // a fake scale for debugging purposes
            return new ScaleScreen();
        } else if ("fake".equals(type)) { // a fake scale for debugging purposes
            return new ScaleFake();
        } else if ("null".equals(type)) {
            return new ScaleNull();
        } else {
            return null;
        }
    }

    public DeviceFiscalPrinter getFiscal(String type, HardwareConfig hwconfig) throws Exception {

        if ("eltrade".equals(type)) {
            return new DeviceFiscalActiveXEltrade(hwconfig.getParameter1(), hwconfig.getParameter2());
        } else {
            return null;
        }
    }    
}
