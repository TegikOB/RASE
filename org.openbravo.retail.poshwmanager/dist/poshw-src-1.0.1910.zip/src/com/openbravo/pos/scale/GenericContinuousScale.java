/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.openbravo.pos.scale;

import static com.openbravo.pos.scale.ScaleSerial.SCALE_READY;
import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.UnsupportedCommOperationException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.TooManyListenersException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringEscapeUtils;

/**
 *
 * @author openbravo
 */
public class GenericContinuousScale extends ScaleSerial{
    /*
 ************************************************************************************
 * Copyright (C) 2013 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

    
    private static final Logger logger = Logger.getLogger(com.openbravo.pos.scale.GenericScale.class.getName());
    
    private int finalchar;
    private Pattern pattern;
    private double factor;
       
    /** Creates a new instance of ScaleDialog1 */
    public GenericContinuousScale(String param1, String param2, String finalchar, String pattern, String factor) throws ScaleException, UnsupportedEncodingException {
        super(param1, param2);
        
        this.finalchar = StringEscapeUtils.unescapeJava(finalchar).charAt(0);
        this.pattern = Pattern.compile(pattern);
        this.factor = parseDouble(factor, 0.001);             
    }
    
    @Override
    public String getScaleName() {
        return "Generic protocol ";
    }

    @Override
    protected byte[] getWeightCommand() {
        return null;
    }

    
    public void initialize(){
        
        try {
            if (in == null) {
                comport = CommPortIdentifier.getPortIdentifier(port); // Tomamos el puerto
                serialport = (SerialPort) comport.open("PORTID", 2000); // Abrimos el puerto

                in = serialport.getInputStream();

                serialport.addEventListener(this);
                serialport.notifyOnDataAvailable(true);

                serialport.setSerialPortParams(bauds, databits, stopbits, parity);
                serialport.setFlowControlMode(flowcontrol);
            }
        } catch (NoSuchPortException e) {
            logger.log(Level.SEVERE, null, e);
        } catch (PortInUseException e) {
            logger.log(Level.SEVERE, null, e);
        } catch (UnsupportedCommOperationException e) {
            logger.log(Level.SEVERE, null, e);
        } catch (TooManyListenersException e) {
            logger.log(Level.SEVERE, null, e);
        } catch (IOException e) {
            logger.log(Level.SEVERE, null, e);
        }
    
    }
    
    @Override
    public Double readWeight() throws ScaleException {

      //  synchronized(this) {

            if (status != SCALE_READY) {
                try {
                    wait(1000);
                } catch (InterruptedException e) {
                }
                if (status != SCALE_READY) {
                    // wrong status.
                    status = SCALE_READY;
                }
            }

            // Ready
            buffer.clear();
            initialize();

            // Wait for one second
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
            
            if (status == SCALE_READY) {
                // parse buffer
                Double d = parseWeight(readBytes);
                System.out.println("weight:"+d);
                buffer.clear();
                return d;
            } else {
                status = SCALE_READY;
                System.out.println("holaaa");
                return new Double(0.0);
            }
        
    }
    
    
    public void serialEvent(SerialPortEvent e) {

	// Determine type of event.
	switch (e.getEventType()) {
            case SerialPortEvent.BI:
            case SerialPortEvent.OE:
            case SerialPortEvent.FE:
            case SerialPortEvent.PE:
            case SerialPortEvent.CD:
            case SerialPortEvent.CTS:
            case SerialPortEvent.DSR:
            case SerialPortEvent.RI:
            case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
                break;
            case SerialPortEvent.DATA_AVAILABLE:
                try {
                    while (in.available() > 0) {
                        int b = in.read();
                        if (isFinal(b)) { // CR ASCII
                            synchronized (this) {
                                status = SCALE_READY;
                                readBytes=convertBuffer();
                                buffer.clear();
                                notifyAll();
                            }
                        } else if (isValid(b)){
                            synchronized(this) {
                                    buffer.add(b);
                            }
                        } else {
                            // invalid character
                            synchronized(this) {
                                buffer.clear();
                                status = SCALE_READY;
                            }
                        }
                    }

                } catch (IOException eIO) {
                    logger.log(Level.SEVERE, null, eIO);
                }
                break;
        }
    }
    
    @Override
    protected Double parseWeight(byte[] buffer) throws ScaleException {
        
        String p = null;
        try {
            p = new String(buffer, "ISO-8859-1");
        } catch (UnsupportedEncodingException ex) {
        }    
        Matcher m = pattern.matcher(p.trim());
        double weight;
        if (m.matches()) {
            if (m.groupCount() == 1) {
                weight = parseInt(m.group(1), 0) * factor;
            } else if (m.groupCount() == 2) {
                weight = parseDouble (m.group(1) + "." + m.group(2), 0.0);
            } else {
                throw new ScaleException("Returned weight cannot be parsed: " + p);
            }

            return new Double(weight < 0.002 ? 0.0 : weight); // ignore scale adjusting
        } else {
            throw new ScaleException("Returned weight cannot be parsed: " + p);
        }
    }

    @Override
    protected boolean isFinal(int b) {
        return b == finalchar; // RS ASCII
    }

    @Override
    protected boolean isValid(int b) {
        return true;
    }
    
    private static double parseDouble(String value, double def) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException eNF) {
            return def;
        } catch (NullPointerException eNF) {
            return def;
        }
    }    
    private static int parseInt(String sValue, int iDefault) {
        try {
            return Integer.parseInt(sValue);
        } catch (NumberFormatException eNF) {
            return iDefault;
        }
    }    
}

