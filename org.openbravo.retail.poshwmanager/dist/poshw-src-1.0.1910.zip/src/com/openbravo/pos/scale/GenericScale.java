/*
 ************************************************************************************
 * Copyright (C) 2013 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.scale;

import java.io.UnsupportedEncodingException;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;

/**
 *
 * @author adrian
 */
public class GenericScale extends ScaleSerial {
    
    private static final Logger logger = Logger.getLogger(GenericScale.class.getName());
    
    private byte[] command;
    private int finalchar;
    private Pattern pattern;
    private double factor;
       
    /** Creates a new instance of ScaleDialog1 */
    public GenericScale(String param1, String param2, String commandstr, String finalchar, String pattern, String factor) throws ScaleException, UnsupportedEncodingException {
        super(param1, param2);
        
        this.command = StringEscapeUtils.unescapeJava(commandstr).getBytes("ISO-8859-1");
        this.finalchar = StringEscapeUtils.unescapeJava(finalchar).charAt(0);
        this.pattern = Pattern.compile(pattern);
        this.factor = parseDouble(factor, 0.001);             
    }
    
    @Override
    public String getScaleName() {
          return "Generic protocol ";
    }

    @Override
    protected byte[] getWeightCommand() {
        return command;
    }

    @Override
    protected Double parseWeight(byte[] buffer) throws ScaleException {
        		
        String p = null;
        try {
            p = new String(buffer, "ISO-8859-1");
        } catch (UnsupportedEncodingException ex) {
        }    
        
        Matcher m = pattern.matcher(p);
        double weight;
        if (m.matches()) {
            if (m.groupCount() == 1) {
                weight = parseInt(m.group(1), 0) * factor;
            } else if (m.groupCount() == 2) {
                weight = parseDouble (m.group(1) + "." + m.group(2), 0.0);
            } else {
                throw new ScaleException("Returned weight cannot be parsed: " + p);
            }

            return new Double(weight < 0.002 ? 0.0 : weight); // ignore scale adjusting
        } else {
            throw new ScaleException("Returned weight cannot be parsed: " + p);
        }
    }

    @Override
    protected boolean isFinal(int b) {
        return b == finalchar; // RS ASCII
    }

    @Override
    protected boolean isValid(int b) {
        return true;
    }
    
    private static double parseDouble(String value, double def) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException eNF) {
            return def;
        } catch (NullPointerException eNF) {
            return def;
        }
    }    
    private static int parseInt(String sValue, int iDefault) {
        try {
            return Integer.parseInt(sValue);
        } catch (NumberFormatException eNF) {
            return iDefault;
        }
    }    
}
