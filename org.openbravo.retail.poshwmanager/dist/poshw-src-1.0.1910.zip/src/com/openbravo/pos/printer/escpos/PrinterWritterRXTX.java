/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

// import javax.comm.*; // Java comm library
import gnu.io.*;

import java.io.*;

import com.openbravo.pos.printer.TicketPrinterException;

public class PrinterWritterRXTX extends PrinterWritter /* implements SerialPortEventListener */{

    private static final int BUFFER_SIZE = 2048;

    private CommPortIdentifier m_PortIdPrinter;
    private CommPort m_CommPortPrinter;

    private final String m_sPortPrinter;
    private final int bauds;
    private final int databits;
    private final int stopbits;
    private final int parity;
    private final int flowcontrol;

    private OutputStream m_out;
    private InputStream m_in;

    /** Creates a new instance of PrinterWritterComm */
    public PrinterWritterRXTX(String sPortPrinter) throws TicketPrinterException {
        this(sPortPrinter, 9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1,
                SerialPort.PARITY_NONE, SerialPort.FLOWCONTROL_NONE);
    }

    /** Creates a new instance of PrinterWritterComm */
    public PrinterWritterRXTX(String sPortPrinter, int bauds, int databits, int stopbits,
            int parity, int flowcontrol) throws TicketPrinterException {
        m_sPortPrinter = sPortPrinter;
        this.bauds = bauds; // Default 9600
        this.databits = databits; // Default 8
        this.stopbits = stopbits; // Default 1
        this.parity = parity; // Default 0
        this.flowcontrol = flowcontrol; // Default 0: NONE
        m_out = null;
    }

    public String getDescription() {
        return "Serial port: " + m_sPortPrinter + ".";
    }

    protected void internalWrite(byte[] data) {
        try {
            if (m_out == null) {
                m_PortIdPrinter = CommPortIdentifier.getPortIdentifier(m_sPortPrinter); // Tomamos
                                                                                        // el puerto
                m_CommPortPrinter = m_PortIdPrinter.open("PORTID", 2000); // Abrimos el puerto

                m_out = new BufferedOutputStream(m_CommPortPrinter.getOutputStream(), BUFFER_SIZE); // Tomamos
                                                                                                    // el
                                                                                                    // chorro
                                                                                                    // de
                                                                                                    // escritura

                if (m_PortIdPrinter.getPortType() == CommPortIdentifier.PORT_SERIAL) {
                    ((SerialPort) m_CommPortPrinter).setSerialPortParams(bauds, databits, stopbits,
                            parity); // Configuramos el puerto
                    ((SerialPort) m_CommPortPrinter).setFlowControlMode(flowcontrol);

                    // this line prevents the printer tmu220 to stop printing after +-18 lines
                    // printed. Bug 8324
                    // But if added a regression error appears. Bug 9417, Better to keep it
                    // commented.
                    // ((SerialPort)m_CommPortPrinter).setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN);
                    // Not needed to set parallel properties
                    // } else if (m_PortIdPrinter.getPortType() == CommPortIdentifier.PORT_PARALLEL)
                    // {
                    // ((ParallelPort)m_CommPortPrinter).setMode(1);
                }
            }
            m_out.write(data);
        } catch (NoSuchPortException e) {
            System.err.println(e);
        } catch (PortInUseException e) {
            System.err.println(e);
        } catch (UnsupportedCommOperationException e) {
            System.err.println(e);
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    protected void internalFlush() {
        try {
            if (m_out != null) {
                m_out.flush();
            }
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    protected String internalRead() {
        try {
            m_in = new BufferedInputStream(new FileInputStream(m_sPortPrinter), BUFFER_SIZE);

            int status = m_in.read();
            m_in.close();
            if (status == 0) {
                return "Opened";
            } else if (status == 1) {
                return "Closed";
            } else {
                return "Error";
            }
        } catch (IOException e) {
            System.err.println(e);
            return "Error";
        }
    }

    protected void internalClose() {
        try {
            if (m_out != null) {
                m_out.flush();
                m_out.close();
                m_out = null;
                m_CommPortPrinter = null;
                m_PortIdPrinter = null;
            }
        } catch (IOException e) {
            System.err.println(e);
        }
    }
}
