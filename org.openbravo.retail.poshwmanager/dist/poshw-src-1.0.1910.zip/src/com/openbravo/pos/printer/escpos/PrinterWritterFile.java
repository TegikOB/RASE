/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import java.io.*;

public class PrinterWritterFile extends PrinterWritter {

    private static final int BUFFER_SIZE = 2048;

    private final String m_sFilePrinter;

    private OutputStream m_out;
    private InputStream m_in;

    public PrinterWritterFile(String sFilePrinter) {
        m_sFilePrinter = sFilePrinter;
        m_out = null;
    }

    public String getDescription() {
        return "File port: " + m_sFilePrinter + ".";
    }

    protected void internalWrite(byte[] data) {
        try {
            if (m_out == null) {
                m_out = new BufferedOutputStream(new FileOutputStream(m_sFilePrinter), BUFFER_SIZE); // No
                                                                                                     // poner
                                                                                                     // append
                                                                                                     // =
                                                                                                     // true.
            }
            m_out.write(data);
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    protected String internalRead() {
        try {
            m_in = new BufferedInputStream(new FileInputStream(m_sFilePrinter), BUFFER_SIZE);

            int status = m_in.read();
            m_in.close();
            if (status == 0) {
                return "Opened";
            } else if (status == 1) {
                return "Closed";
            } else {
                return "Error";
            }
        } catch (IOException e) {
            System.err.println(e);
            return "Error";
        }
    }

    protected void internalFlush() {
        try {
            if (m_out != null) {
                m_out.flush();
                m_out.close();
                m_out = null;
            }
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    protected void internalClose() {
        try {
            if (m_out != null) {
                m_out.flush();
                m_out.close();
                m_out = null;
            }
        } catch (IOException e) {
            System.err.println(e);
        }
    }
}
