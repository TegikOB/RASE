/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.ticket;

import java.awt.Graphics2D;

public interface PrintItem {
    
    public int getHeight();
    public void draw(Graphics2D g, int x, int y, int width);
}
