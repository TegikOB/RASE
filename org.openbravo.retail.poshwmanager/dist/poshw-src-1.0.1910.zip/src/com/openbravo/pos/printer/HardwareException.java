/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer;

public class HardwareException extends java.lang.Exception {

    public HardwareException() {
    }

    public HardwareException(String msg) {
        super(msg);
    }
    public HardwareException(Throwable cause) {
        super(cause);
    }
    public HardwareException(String msg, Throwable cause) {
        super(msg, cause);
    }
}

