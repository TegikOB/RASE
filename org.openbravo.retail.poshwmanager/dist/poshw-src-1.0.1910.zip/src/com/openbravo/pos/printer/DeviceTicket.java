/*
 ************************************************************************************
 * Copyright (C) 2012 - 2013 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer;

import com.openbravo.pos.scale.DeviceScale;
import com.openbravo.pos.scale.ScaleNull;
import java.util.*;
import com.openbravo.pos.service.HardwareConfig;
import com.openbravo.pos.service.HardwareConfigInst;
import com.openbravo.pos.service.HardwareService;

import com.openbravo.pos.util.StringParser;
import com.openbravo.poshw.AppConfig;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DeviceTicket {

    private static final Logger logger = Logger.getLogger(DeviceTicket.class.getName());

    private DeviceFiscalPrinter nullfiscal;
    private Map<String, DeviceFiscalPrinter> deviceFiscals;
    private List<DeviceFiscalPrinter> deviceFiscalsList;

    private DeviceDisplay m_devicedisplay;

    private DevicePrinter m_nullprinter;
    private Map<String, DevicePrinter> devicePrinters;
    private List<DevicePrinter> devicePrintersList;
    private DeviceScale devicescale;

    public DeviceTicket(AppConfig config) {

        HardwareConfigInst hwconfig = new HardwareConfigInst(config);
        ServiceLoader<HardwareService> hwserviceloader = ServiceLoader.load(HardwareService.class);
        
        
        nullfiscal = new DeviceFiscalPrinterNull();
        deviceFiscals = new HashMap<String, DeviceFiscalPrinter>();
        deviceFiscalsList = new ArrayList<DeviceFiscalPrinter>();

        int iFiscalIndex = 1;
        String sFiscalIndex = Integer.toString(iFiscalIndex);
        String sfiscal = config.getProperty("machine.fiscalprinter");

        while (sfiscal != null && !"".equals(sfiscal)) {

            StringParser sf = new StringParser(sfiscal);
            String sFiscalType = sf.nextToken(':');
            String sFiscalParam1 = sf.nextToken(',');
            String sFiscalParam2 = sf.nextToken(Character.MIN_VALUE);
            DeviceFiscalPrinter fiscal;
            
            try {
                hwconfig.setParameters(sFiscalParam1, sFiscalParam2);
                fiscal = findDeviceFiscal(hwserviceloader, sFiscalType, hwconfig);
            } catch (Exception e) {
                logger.log(Level.WARNING, e.getMessage(), e);
                fiscal = new DeviceFiscalPrinterNull(e.getMessage());
            }
            deviceFiscals.put(sFiscalIndex, fiscal);
            deviceFiscalsList.add(fiscal);

            // next printer
            iFiscalIndex++;
            sFiscalIndex = Integer.toString(iFiscalIndex);
            sfiscal = config.getProperty("machine.fiscalprinter." + sFiscalIndex);
        }

        // El visor
        StringParser sd = new StringParser(config.getProperty("machine.display"));
        String sDisplayType = sd.nextToken(':');
        String sDisplayParam1 = sd.nextToken(',');
        String sDisplayParam2 = sd.nextToken(Character.MIN_VALUE);

        // compatibilidad hacia atras.
        if ("serial".equals(sDisplayType) || "rxtx".equals(sDisplayType) || "file".equals(sDisplayType)) {
            sDisplayParam2 = sDisplayParam1;
            sDisplayParam1 = sDisplayType;
            sDisplayType = "epson";
        }

        try {
            hwconfig.setParameters(sDisplayParam1, sDisplayParam2);
            m_devicedisplay = findDeviceDisplay(hwserviceloader, sDisplayType, hwconfig);
//        } catch (InvocationTargetException e) {
//        } catch (ClassNotFoundException e) {
//        } catch (InstantiationException e) {
//        } catch (IllegalAccessException e) {
//        } catch (NoSuchMethodException e) {
//        } catch (IllegalArgumentException e) {
//        } catch (TicketPrinterException e) {
        } catch (Exception e) {
            logger.log(Level.WARNING, e.getMessage(), e);
            m_devicedisplay = new DeviceDisplayNull(e.getMessage());
        }

        m_nullprinter = new DevicePrinterNull();
        devicePrinters = new HashMap<String, DevicePrinter>();
        devicePrintersList = new ArrayList<DevicePrinter>();

        // Empezamos a iterar por las impresoras...
        int iPrinterIndex = 1;
        String sPrinterIndex = Integer.toString(iPrinterIndex);
        String sprinter = config.getProperty("machine.printer");

        while (sprinter != null && !"".equals(sprinter)) {

            StringParser sp = new StringParser(sprinter);
            String sPrinterType = sp.nextToken(':');
            String sPrinterParam1 = sp.nextToken(',');
            String sPrinterParam2 = sp.nextToken(Character.MIN_VALUE);
            DevicePrinter printer;

            // compatibilidad hacia atras.
            if ("serial".equals(sPrinterType) || "rxtx".equals(sPrinterType) || "file".equals(sPrinterType)) {
                sPrinterParam2 = sPrinterParam1;
                sPrinterParam1 = sPrinterType;
                sPrinterType = "epson";
            }

            try {
                hwconfig.setParameters(sPrinterParam1, sPrinterParam2);
                printer = findDevicePrinter(hwserviceloader, sPrinterType, hwconfig);
                
//            } catch (InvocationTargetException e) {
//            } catch (ClassNotFoundException e) {
//            } catch (InstantiationException e) {
//            } catch (IllegalAccessException e) {
//            } catch (NoSuchMethodException e) {
//            } catch (IllegalArgumentException e) {
//            } catch (TicketPrinterException e) {
            } catch (Exception e) {
                logger.log(Level.WARNING, e.getMessage(), e);
                printer = new DevicePrinterNull();
            }
            devicePrinters.put(sPrinterIndex, printer);
            devicePrintersList.add(printer);

            // next printer
            iPrinterIndex++;
            sPrinterIndex = Integer.toString(iPrinterIndex);
            sprinter = config.getProperty("machine.printer." + sPrinterIndex);
        }

        // The scale

        sd = new StringParser(config.getProperty("machine.scale"));
        String sScaleType = sd.nextToken(':');
        String sScaleParam1 = sd.nextToken(',');
        String sScaleParam2 = sd.nextToken(Character.MIN_VALUE);
        try {
            hwconfig.setParameters(sScaleParam1, sScaleParam2);
            devicescale = findDeviceScale(hwserviceloader, sScaleType, hwconfig);
//        } catch (InvocationTargetException e) {
//        } catch (ClassNotFoundException e) {
//        } catch (InstantiationException e) {
//        } catch (IllegalAccessException e) {
//        } catch (NoSuchMethodException e) {
//        } catch (IllegalArgumentException e) {
//        } catch (TicketPrinterException e) {
        } catch (Exception e) {
            logger.log(Level.WARNING, e.getMessage(), e);
            devicescale = new ScaleNull(e.getMessage());
        }
    }

    private DeviceDisplay findDeviceDisplay(ServiceLoader<HardwareService> hwserviceloader, String type, HardwareConfig hwconfig) throws Exception {
        DeviceDisplay dd;
        for (HardwareService hws : hwserviceloader) {
            dd = hws.getDisplay(type, hwconfig);
            if (dd != null) {
                return dd;
            }
        }
        return new DeviceDisplayNull("Unknown type: \"" + type + "\".");
    }

    private DevicePrinter findDevicePrinter(ServiceLoader<HardwareService> hwserviceloader, String type, HardwareConfig hwconfig) throws Exception {
        DevicePrinter dp;
        for (HardwareService hws : hwserviceloader) {
            dp = hws.getPrinter(type, hwconfig);
            if (dp != null) {
                return dp;
            }
        }
        return new DevicePrinterNull("Unknown type: \"" + type + "\".");
    }

    private DeviceFiscalPrinter findDeviceFiscal(ServiceLoader<HardwareService> hwserviceloader, String type, HardwareConfig hwconfig) throws Exception {
        DeviceFiscalPrinter dp;
        for (HardwareService hws : hwserviceloader) {
            dp = hws.getFiscal(type, hwconfig);
            if (dp != null) {
                return dp;
            }
        }
        return new DeviceFiscalPrinterNull("Unknown type: \"" + type + "\".");
    }

    private DeviceScale findDeviceScale(ServiceLoader<HardwareService> hwserviceloader, String type, HardwareConfig hwconfig) throws Exception {
        DeviceScale ds;
        for (HardwareService hws : hwserviceloader) {
            ds = hws.getScale(type, hwconfig);
            if (ds != null) {
                return ds;
            }
        }
        return new ScaleNull("Unknown type: \"" + type + "\".");
    }

    // Impresora fiscal
    public DeviceFiscalPrinter getFiscalPrinter(String key) {
        DeviceFiscalPrinter fiscal = deviceFiscals.get(key);
        return fiscal == null ? nullfiscal : fiscal;
    }
    public List<DeviceFiscalPrinter> getFiscalPrinterAll() {
        return deviceFiscalsList;
    }


    // Display
    public DeviceDisplay getDeviceDisplay() {
        return m_devicedisplay;
    }
    // Receipt printers
    public DevicePrinter getDevicePrinter(String key) {
        DevicePrinter printer = devicePrinters.get(key);
        return printer == null ? m_nullprinter : printer;
    }

    public List<DevicePrinter> getDevicePrinterAll() {
        return devicePrintersList;
    }
    // Scale
    public DeviceScale getDeviceScale() {
        return devicescale;
    }
    // Utilidades
    public static String getWhiteString(int iSize, char cWhiteChar) {

        char[] cFill = new char[iSize];
        for (int i = 0; i < iSize; i++) {
            cFill[i] = cWhiteChar;
        }
        return new String(cFill);
    }

    public static String getWhiteString(int iSize) {

        return getWhiteString(iSize, ' ');
    }

    public static String alignBarCode(String sLine, int iSize) {

        if (sLine.length() > iSize) {
            return sLine.substring(sLine.length() - iSize);
        } else {
            return getWhiteString(iSize - sLine.length(), '0') + sLine;
        }
    }

    public static String alignLeft(String sLine, int iSize) {

        if (sLine.length() > iSize) {
            return sLine.substring(0, iSize);
        } else {
            return sLine + getWhiteString(iSize - sLine.length());
        }
    }

    public static String alignRight(String sLine, int iSize) {

        if (sLine.length() > iSize) {
            return sLine.substring(sLine.length() - iSize);
        } else {
            return getWhiteString(iSize - sLine.length()) + sLine;
        }
    }

    public static String alignCenter(String sLine, int iSize) {

        if (sLine.length() > iSize) {
            return alignRight(sLine.substring(0, (sLine.length() + iSize) / 2), iSize);
        } else {
            return alignRight(sLine + getWhiteString((iSize - sLine.length()) / 2), iSize);
        }
    }

    public static String alignCenter(String sLine) {
        return alignCenter(sLine, 42);
    }

    public static byte[] transNumber(String sCad) {

        if (sCad == null) {
            return null;
        } else {
            byte bAux[] = new byte[sCad.length()];
            for( int i = 0; i < sCad.length(); i++) {
                bAux[i] = transNumberChar(sCad.charAt(i));
            }
            return bAux;
        }
    }

    public static byte transNumberChar(char sChar) {
        switch (sChar) {
        case '0' : return 0x30;
        case '1' : return 0x31;
        case '2' : return 0x32;
        case '3' : return 0x33;
        case '4' : return 0x34;
        case '5' : return 0x35;
        case '6' : return 0x36;
        case '7' : return 0x37;
        case '8' : return 0x38;
        case '9' : return 0x39;
        default: return 0x30;
        }
    }

    private static int parseInt(String sValue, int iDefault) {
        try {
            return Integer.parseInt(sValue);
        } catch (NumberFormatException eNF) {
            return iDefault;
        }
    }

    private static int parseInt(String sValue) {
        return parseInt(sValue, 0);
    }
}
