/*
 ************************************************************************************
 * Copyright (C) 2012 - 2013 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer;

import javax.swing.JComponent;

public interface DeviceFiscalPrinter {
    
    public static final String TYPE_NONFISCAL = "nonfiscal"; // Default
    public static final String TYPE_FISCAL = "fiscal";   
    public static final String TYPE_INVOICE = "invoice";
    
    public static final String STYLE_NORMAL = "normal";
    public static final String STYLE_BOLD = "bold";
    public static final String STYLE_ITALIC = "italic";
    public static final String STYLE_UNDERLINE = "underline";
    public static final String STYLE_DOUBLEWIDTH = "doublewidth";
    public static final String STYLE_DOUBLEHEIGHT = "doubleheight";
    
    public String getFiscalName();
    public String getFiscalDescription();
    public JComponent getFiscalComponent();

    public void reset() throws HardwareException;
    public void test() throws HardwareException;
    
    public void beginReceipt(String type, String cashier) throws HardwareException;
    public void beginReceipt(String type, String cashier, String invNumber, String taxNumber, String vatNumber, String name, String address) throws HardwareException;
    public void endReceipt() throws HardwareException;
    public void printLine(String sproduct, double dprice, double dunits, int taxinfo, double discount) throws HardwareException; // discount in %. Can be positive or negative.
    public void printLine(String sproduct, double dprice, double dunits, int taxinfo) throws HardwareException; // discount is 0.0
    public void printMessage(String style, String smessage) throws HardwareException;   
    public void printDiscount(double discount) throws HardwareException; // discount in %. Can be positive or negative.
    public void printServiceCharge(double amount) throws HardwareException; // charge in total. Can be positive or negative.
    public void printTotal(int paymentId, String paymentName, double amount) throws HardwareException;
    
    public void printCashManagement(int paymentId, String paymentName, double amount) throws HardwareException;
    public void printZReport() throws HardwareException;
    public void printXReport() throws HardwareException;
}
