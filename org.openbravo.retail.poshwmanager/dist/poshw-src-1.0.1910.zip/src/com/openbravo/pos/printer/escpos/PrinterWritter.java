/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.printer.escpos;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class PrinterWritter {

    private boolean initialized = false;

    private ExecutorService exec;

    public PrinterWritter() {
        exec = Executors.newSingleThreadExecutor();
    }

    public abstract String getDescription();

    protected abstract void internalWrite(byte[] data);

    protected String internalRead() {
        return internalRead();
    }

    protected abstract void internalFlush();

    protected abstract void internalClose();

    public void init(final byte[] data) {
        if (!initialized) {
            write(data);
            initialized = true;
        }
    }

    public void write(String sValue) {
        write(sValue.getBytes());
    }

    public void write(byte b) {
        write(new byte[] { b });
    }

    public void write(final byte[] data) {
        exec.execute(new Runnable() {
            public void run() {
                internalWrite(data);
            }
        });
    }

    public String read() {
        return internalRead();
    }

    public void flush() {
        exec.execute(new Runnable() {
            public void run() {
                internalFlush();
            }
        });
    }

    public void close() {
        exec.execute(new Runnable() {
            public void run() {
                internalClose();
            }
        });
        exec.shutdown();
    }
}
