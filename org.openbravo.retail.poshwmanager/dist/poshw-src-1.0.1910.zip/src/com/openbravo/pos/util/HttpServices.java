/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 *
 * @author adrian
 */
public class HttpServices {

    public static HttpResult doPost(String location, String contentType, String query) throws IOException {

        BufferedReader readerin = null;
        Writer writerout = null;

        try {

            URL url = new URL(location);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setAllowUserInteraction(false);

            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setDoOutput(true);

            connection.setRequestProperty("Content-length", String.valueOf(query.length()));
            connection.setRequestProperty("Content-Type", contentType);

            writerout = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
            writerout.write(query);
            writerout.flush();

            writerout.close();
            writerout = null;

            int responsecode = connection.getResponseCode();
            if (responsecode == HttpURLConnection.HTTP_OK) {
                String resultType = connection.getContentType();
                StringBuilder text = new StringBuilder();
                readerin = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String line = null;
                while ((line = readerin.readLine()) != null) {
                    text.append(line);
                    text.append(System.getProperty("line.separator"));
                }
                return new HttpResult(resultType, text.toString());
            } else {
                throw new IOException(Integer.toString(responsecode) + ": " +connection.getResponseMessage());
            }
        } finally {
            if (writerout != null) {
                try {
                    writerout.close();
                } catch (IOException ex) {
                }
                writerout = null;
            }
            if (readerin != null) {
                try {
                    readerin.close();
                } catch (IOException ex) {
                }
                readerin = null;
            }
        }
    }

    public static HttpResult doGet(String location, String contentType) throws IOException {

        BufferedReader readerin = null;
        Writer writerout = null;

        try {

            URL url = new URL(location);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");

            int responsecode = connection.getResponseCode();
            if (responsecode == HttpURLConnection.HTTP_OK) {
                String resultType = connection.getContentType();
                StringBuilder text = new StringBuilder();
                readerin = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String line = null;
                while ((line = readerin.readLine()) != null) {
                    text.append(line);
                    text.append(System.getProperty("line.separator"));
                }
                return new HttpResult(resultType, text.toString());
            } else {
                throw new IOException(Integer.toString(responsecode) + ": " +connection.getResponseMessage());
            }
        } finally {
            if (writerout != null) {
                try {
                    writerout.close();
                } catch (IOException ex) {
                }
                writerout = null;
            }
            if (readerin != null) {
                try {
                    readerin.close();
                } catch (IOException ex) {
                }
                readerin = null;
            }
        }
    }
}
