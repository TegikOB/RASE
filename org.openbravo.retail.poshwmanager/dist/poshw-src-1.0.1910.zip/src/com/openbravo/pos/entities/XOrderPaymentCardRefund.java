/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.entities;

public class XOrderPaymentCardRefund extends XOrderPaymentCard {
    
    /** Creates a new instance of PaymentInfoMagcardRefund */
    public XOrderPaymentCardRefund(String sHolderName, String sCardNumber, String sExpirationDate, String track1, String track2, String track3, double total) {
       super(sHolderName, sCardNumber, sExpirationDate, track1, track2, track3, total);
    }
    
    /** Creates a new instance of PaymentInfoMagcard */
    public XOrderPaymentCardRefund(String sHolderName, String sCardNumber, String sExpirationDate, double total) {
        super(sHolderName, sCardNumber, sExpirationDate, total);
    }   
}
