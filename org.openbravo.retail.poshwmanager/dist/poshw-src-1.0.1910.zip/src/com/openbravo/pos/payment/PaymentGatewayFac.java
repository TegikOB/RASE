/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.payment;

import java.util.Properties;

public class PaymentGatewayFac {
    
    /** Creates a new instance of PaymentGatewayFac */
    private PaymentGatewayFac() {
    }
    
    public static PaymentGateway getPaymentGateway(String paymentgateway, Properties paymentgatewayprops) {

        if ("external".equals(paymentgateway)) {
            return new PaymentGatewayExt();
//        } else if ("PayPoint / SecPay".equals(paymentgateway)) {
//            return new PaymentGatewayPayPoint(paymentgatewayoptions);
        } else if ("AuthorizeNet".equals(paymentgateway)) {
            return new PaymentGatewayAuthorizeNet(paymentgatewayprops);
        } else if ("La Caixa (Spain)".equals(paymentgateway)) {
            return new PaymentGatewayCaixa(paymentgatewayprops);
        } else if ("Planetauthorize".equals(paymentgateway)) {
            return new PaymentGatewayPlanetauthorize(paymentgatewayprops);
        } else if ("Firs Data / LinkPoint / YourPay".equals(paymentgateway)) {
            return new PaymentGatewayLinkPoint(paymentgatewayprops);
        } else if ("PaymentsGateway.net".equals(paymentgateway)) {
            return new PaymentGatewayPGNET(paymentgatewayprops);
        } else {
            return null;
        }
    }      
}
