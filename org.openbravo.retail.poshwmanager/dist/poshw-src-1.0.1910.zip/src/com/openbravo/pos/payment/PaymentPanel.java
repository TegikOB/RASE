/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.payment;

import com.openbravo.pos.entities.XOrderPaymentCard;
import javax.swing.JComponent;

public interface PaymentPanel {
    
    public void activate(double dTotal);
    public JComponent getComponent();
    public XOrderPaymentCard getPaymentInfoMagcard();
}
