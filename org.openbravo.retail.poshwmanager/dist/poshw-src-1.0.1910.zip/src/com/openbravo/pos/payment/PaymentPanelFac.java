/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.payment;

/**
 *
 * @author adrianromero
 */
public class PaymentPanelFac {
    
    /** Creates a new instance of PaymentPanelFac */
    private PaymentPanelFac() {
    }
    
    public static PaymentPanel getPaymentPanel(String sReader, JPaymentNotifier notifier) {
        
        if ("Intelligent".equals(sReader)) {
            return new PaymentPanelMagCard(new MagCardReaderIntelligent(), notifier);
        } else if ("Generic".equals(sReader)) {
            return new PaymentPanelMagCard(new MagCardReaderGeneric(), notifier);
        } else if ("Alternative".equals(sReader)) {
            return new PaymentPanelMagCard(new MagCardReaderAlternative(), notifier);
        } else if ("Keyboard".equals(sReader)) {
            return new PaymentPanelType(notifier);
        } else { // "Not defined
            return new PaymentPanelBasic(notifier);
        }
    }      
}
