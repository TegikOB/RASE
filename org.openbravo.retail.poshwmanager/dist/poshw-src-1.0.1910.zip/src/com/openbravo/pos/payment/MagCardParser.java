/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.payment;

/**
 *
 * @author adrian
 */
public interface MagCardParser {

    public void reset();
    public void append(char c);
    public boolean isComplete();

    public String getHolderName();
    public String getCardNumber();
    public String getExpirationDate();

    public String getTrack1();
    public String getTrack2();
    public String getTrack3();
}
