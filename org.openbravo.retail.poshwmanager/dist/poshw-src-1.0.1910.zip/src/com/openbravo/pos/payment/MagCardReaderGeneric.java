/*
 ************************************************************************************
 * Copyright (C) 2012 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */

package com.openbravo.pos.payment;

public class MagCardReaderGeneric implements MagCardReader {

    private MagCardParser magcardparser;
    
    /** Creates a new instance of GenericMagCardReader */
    public MagCardReaderGeneric() {
        magcardparser = new MagCardParserGeneric();
    }

    @Override
    public String getReaderName() {
        return "Basic magnetic card reader";
    }
    @Override
    public void keyPressed(java.awt.event.KeyEvent evt) {
    }
    @Override
    public void keyReleased(java.awt.event.KeyEvent evt) {
    }
    @Override
    public void keyTyped(java.awt.event.KeyEvent evt) {
        magcardparser.append(evt.getKeyChar());
    }
    @Override
    public MagCardParser getMagCard() {
        return magcardparser;
    }
}
